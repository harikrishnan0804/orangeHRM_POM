package com.crm.qa.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.Adminpage;
import com.crm.qa.pages.HomePage;
import com.crm.qa.pages.LoginPage;
import com.crm.qa.util.TestUtil;

public class orangeHRMTestCase extends TestBase  {
	LoginPage loginPage;
	HomePage homePage;
	TestUtil testUtil;
	Adminpage adminPage;
	AdminPageElements elements;


	@BeforeTest
	public void setUp() throws InterruptedException {

		initialization();
		testUtil = new TestUtil();
		adminPage = new Adminpage();
		loginPage = new LoginPage();
		homePage = loginPage.login();
		elements =new AdminPageElements();
	}


	@Test(priority=1)
	public void editUserRoleInAdminPage() throws InterruptedException, IOException {
		adminPage.adminPage();
		elements.secondPencilbutton.click();
		Thread.sleep(2000);
		elements.dropdwon.click();
		elements.adminESS.click();
		Thread.sleep(2000);
		String usernname =elements.usernamefield.getAttribute("value");
		elements.save.click();
		String expectedRole=driver.findElement(By.xpath("//div[@class='oxd-table-cell oxd-padding-cell']/child::div[text()='"+usernname+"']")).getText();
		Assert.assertEquals(usernname, expectedRole);
		takeScreenshotAtEndOfTest();
	}
	@AfterTest
	public void tearDown(){
		driver.quit();
	}

}
