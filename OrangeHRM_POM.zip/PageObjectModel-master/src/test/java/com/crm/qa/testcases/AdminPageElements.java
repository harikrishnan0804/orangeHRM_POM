package com.crm.qa.testcases;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class AdminPageElements extends TestBase {

	@FindBy(xpath = "(//div[@class='oxd-table-cell-actions']/child::button[2]/i)[2]")
	WebElement secondPencilbutton;
	@FindBy(xpath = "//div[@class='oxd-select-option']/child::span")
	WebElement adminESS;
	@FindBy(xpath = "(//div[@class='oxd-select-text-input']/following::div[1])[1]")
	WebElement dropdwon;
	@FindBy(xpath = "(//div[@class='oxd-select-wrapper']/child::div/div[1])[1]")
	WebElement roleSelection;
	@FindBy(xpath = "//div[contains(text(),'Admin')]")
	WebElement dropDownValue;
	@FindBy(xpath = "//label[text()='Username']/following::div/input")
	WebElement usernamefield;
	@FindBy(xpath = "//button[@type='submit']")
	WebElement save;

	// Initializing the Page Objects:
	public AdminPageElements() {
		PageFactory.initElements(driver, this);
	}
}
