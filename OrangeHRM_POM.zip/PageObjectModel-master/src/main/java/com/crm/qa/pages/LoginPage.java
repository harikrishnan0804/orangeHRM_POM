package com.crm.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class LoginPage extends TestBase{

	//Page Factory - OR:
	@FindBy(xpath="//div[@class='orangehrm-login-form']/div/div/p[1]")
	WebElement getusername;

	@FindBy(xpath="//div[@class='orangehrm-login-form']/div/div/p[2]")
	WebElement getpassword;
	@FindBy(xpath="//input[@name='username']")
	WebElement username;

	@FindBy(xpath="//input[@name='password']")
	WebElement password;


	@FindBy(xpath="//button[normalize-space(@type='Login')]")
	WebElement loginBtn;


	//Initializing the Page Objects:
	public LoginPage(){
		PageFactory.initElements(driver, this);
	}

	//Actions:
	public String validateLoginPageTitle(){
		System.out.println(driver.getTitle());
		return driver.getTitle();

	}


	public HomePage login(){
		String usname =getusername.getText();
		String pass=getpassword.getText();
		String getUsername = usname.split(" ")[2].strip();
		String getPassword = pass.split(" ")[2].strip();


		username.sendKeys(getUsername);
		password.sendKeys(getPassword);
		//loginBtn.click();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", loginBtn);

		return new HomePage();
	}

}
